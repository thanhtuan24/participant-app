import { CosmosClient } from "@azure/cosmos";

const endpoint: string = "https://cosmo-db-az204.documents.azure.com:443/";
const key: string = "LKv3RLhMYaBTbTBOHvvVZFmEFpUsYALidIrokhSBHLhPqqFryBVFzcmFocLT6MPEVd4dLEoNjirlACDbV0HpFw==";
const client: CosmosClient = new CosmosClient({ endpoint, key });

const databaseId: string = "ParticipantDB";
const containerId: string = "Participant";

interface User {
    userID: string;
    username: string;
    participantDate: string;
    status: string;
}

async function addUser(userID: string, username: string, participantDate: string, status: string): Promise<void> {
    const { database } = await client.databases.createIfNotExists({ id: databaseId });
    const { container } = await database.containers.createIfNotExists({ id: containerId });

    const newItem: User = {
        userID,
        username,
        participantDate,
        status
    };

    const { resource: createdItem } = await container.items.create(newItem);
    console.log(`Created item with id: ${createdItem.id}`);
}

async function getParticipantsByDate(date: string): Promise<User[]> {
    const { container } = await client.database(databaseId).container(containerId);
    const { resources: items } = await container.items.query({
        query: "SELECT * FROM c WHERE c.participantDate = @date",
        parameters: [{ name: "@date", value: date }]
    }).fetchAll();

    return items as User[];
}

async function getUserParticipation(userID: string): Promise<{ participantDate: string, status: string }[]> {
    const { container } = await client.database(databaseId).container(containerId);
    const { resources: items } = await container.items.query({
        query: "SELECT participantDate, status FROM c WHERE c.userID = @userID",
        parameters: [{ name: "@userID", value: userID }]
    }).fetchAll();

    return items as { participantDate: string, status: string }[];
}

async function updateUser(userID: string, participantDate: string, status: string): Promise<void> {

    const { container } = await client.database(databaseId).container(containerId);
    const { resource: item } = await container.item(userID).read();
    item.participantDate = participantDate;
    item.status = status;
    const { resource: updatedItem } = await container.item(userID).replace(item);
    console.log(`Updated item with id: ${updatedItem.id}`);
}

export {
    addUser,
    getParticipantsByDate,
    getUserParticipation,
    updateUser
};
