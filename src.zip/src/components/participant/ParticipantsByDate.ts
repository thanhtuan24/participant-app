// src/components/ParticipantsByDate.tsx
import React, { useState, useEffect, ChangeEvent } from 'react';
import { CosmosClient } from '@azure/cosmos';

const endpoint: string = "<Your-CosmosDB-Endpoint>";
const key: string = "<Your-CosmosDB-Key>";
const client = new CosmosClient({ endpoint, key });

const databaseId: string = "<Your-Database-Id>";
const containerId: string = "<Your-Container-Id>";

interface Participant {
  userID: string;
  username: string;
  status: string;
}

const ParticipantsByDate: React.FC = () => {
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [date, setDate] = useState<string>('');
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    if (date) {
      fetchParticipants(date);
    }
  }, [date]);

  const fetchParticipants = async (date: string) => {
    const { container } = await client.database(databaseId).container(containerId);
    const { resources: items } = await container.items.query({
      query: "SELECT * FROM c WHERE c.participantDate = @date",
      parameters: [{ name: "@date", value: date }]
    }).fetchAll();

    setParticipants(items);
    setCount(items.length);
  };

  const handleDateChange = (event: ChangeEvent<HTMLInputElement>) => {
    setDate(event.target.value);
  };

  const handleAddUser = async () => {
    const newUser = {
      userID: 'user123',
      username: 'John Doe',
      participantDate: date,
      status: 'active'
    };

    const { database } = await client.databases.createIfNotExists({ id: databaseId });
    const { container } = await database.containers.createIfNotExists({ id: containerId });

    const { resource: createdItem } = await container.items.create(newUser);
    console.log(`Created item with id: ${createdItem.id}`);

    fetchParticipants(date);
  };

  return (
    <div>
      <input type="date" value={date} onChange={handleDateChange} />
      <button onClick={handleAddUser}>Add User</button>
      <p>Number of Participants: {count}</p>
      <ul>
        {participants.map(participant => (
          <li key={participant.userID}>{participant.username} - {participant.status}</li>
        ))}
      </ul>
    </div>
  );
};

export default ParticipantsByDate;
