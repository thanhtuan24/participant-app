import {  PartiItem } from "@dts";
import React from "react";
import styled from "styled-components";
import tw from "twin.macro";
import { Icon } from "zmp-ui";

const Container = styled.div`
    ${tw`py-3 px-1 `}
`;

const HeaderContainer = styled.div`
    ${tw`grid-cols-2 flex justify-between gap-6 mb-2 text-[12px] leading-5`}
`;

const TimeContainer = styled.div`
    ${tw` block pl-4 gap-4 text-[#767A7F] text-lg h-fit`}
`;
const FeedbackType = styled.div`
    ${tw`border-[#D7EDFF] border flex mr-4 text-right items-center w-fit text-lg px-1 py-0.5 font-medium justify-end text-[#046DD6] rounded-xl font-medium`}
`;


const Date = styled.div`
    ${tw``}
`;

const BodyContainer = styled.div`
    ${tw`text-[#141414]`}
`;

const SmallText = styled.div`
  ${tw`block font-bold text-sm`}
`;

const Content = styled.div`
    ${tw`block  [line-clamp: 3]`}
`;


export interface ParticipantItemProps {
    data: PartiItem;
}

const ParticipantItem: React.FC<ParticipantItemProps> = ({ data }) => (
        <Container>
            <HeaderContainer>
                <TimeContainer>
                        <Date>{(data.username)}</Date>
                        {/* <Icon size={15} icon="zi-clock-1" /> */}
                        <SmallText style={{ color: data.isMember ? "#4AB5AA" : "orange"}}>{data.isMember? "Thành viên":"Vãng lai"}</SmallText>
                        
                        {data.isMember? 
                        (<SmallText style={{ color: data.numberRegistered > 7 ? "#00FF77" : data.numberRegistered > 3 ? "#F3DA74" : "red"}}>Số ngày đã đi:{data.numberRegistered}</SmallText>)
                        :(
                            ""
                        )}
                        </TimeContainer>
                <FeedbackType
                    style={{ textAlign:"right", backgroundColor: data.status === "yes" ? "rgba(18, 174, 226, 0.1)" :"orange", 
                        color: data.status === "yes" ? "#12AEE2" : "white"}}
                >
                    {data.status==="yes"?"Đã đăng ký":"Không đăng ký"}
                </FeedbackType>
            </HeaderContainer>
        </Container>
    );

export default ParticipantItem;
