import React, { useEffect,useState } from "react";
import {
    HomeHeader,
    Utinities,
} from "@components";
import PageLayout from "@components/layout/PageLayout";
import { APP_UTINITIES, participantDate } from "@constants/utinities";
import { useStore } from "@store";
import { getTodayParticipant,getFullParticipant } from "@service/services";
import { PartiItem } from "@dts";
import PresentList from "@components/feedback/PresentList";
import InfiniteScroll from "react-infinite-scroll-component";
import RegisteredInfo from "./RegisteredInfo";

const HomePage: React.FunctionComponent = () => {
    const [organization] = useStore(state => [
        state.organization,
        state.getOrganization,
    ]);

    const [todayParticipant, setTodayParticipants] = useState<number | undefined>();
    const [participants, setParticipants] = useState<PartiItem[] | undefined>();


    const fetchParticipants = async () => {
          try {
            const listParticipant = await getFullParticipant(participantDate());
            console.log(listParticipant);
            const filteredPartiItems = listParticipant.filter((item) => {
                return item.status === 'yes'  && item.participantDate === participantDate();
              });
              const distinctPartiItems = listParticipant.reduce((acc, current) => {
                const existingItem = acc.find((item) => item.userID === current.userID);
                if (existingItem) {
                  existingItem.numberRegistered = listParticipant.filter((item) => item.userID === current.userID).length;
                } else {
                  let filteredcurrentID =  listParticipant.filter((item) => item.userID === current.userID);
                  current.numberRegistered = filteredcurrentID.length;
                  const existingDate = filteredcurrentID.some((item) => item.participantDate === participantDate());
                  if (existingDate) {
                    current.participantDate = participantDate();
                  } else {
                    current.status = 'no';
                  }
                  acc.push(current);
                }
                return acc;
              }, []).sort((a, b) => {
                if (a.status === 'yes' && a.isMember && !(b.status === 'yes' && b.isMember)) {
                  return -1;
                } else if (b.status === 'yes' && b.isMember && !(a.status === 'yes' && a.isMember)) {
                  return 1;
                } else {
                  return a.isMember === b.isMember ? 1 : -1;
                }
              });
            setParticipants(distinctPartiItems);
            setTodayParticipants(filteredPartiItems.length);
          } catch (error) {
            console.error('Error fetching participants:', error);
            setParticipants(undefined);
          }
      };
    useEffect(() => {
        (async () => {
            
            console.log("Hello");
            fetchParticipants();
        })();
        
    }, []);

    return (
        <PageLayout
            id="home-page"
            customHeader={
                <HomeHeader
                    title="ĐIỂM DANH CẦU LÔNG G7"
                    name={organization?.name || ""}
                />
            }
        >
            {/* <UserInfo /> */}
            <RegisteredInfo data={todayParticipant||0} loading={!(todayParticipant!==undefined)}/>
            <Utinities utinities={APP_UTINITIES} />
            <InfiniteScroll
            dataLength={participants?.length||0}
            next={fetchParticipants}
            hasMore={false}
            loader={null}
            scrollableTarget="feedbacks"
        >
            <PresentList data={participants||[]} loading={!participants}/></InfiniteScroll>
            {/* <ListOA /> */}
            {/* <Contacts /> */}
            {/* <Procedures /> */}
            {/* <NewsSection /> */}
        </PageLayout>
    );
};

export default HomePage;
