/* eslint-disable eol-last */
/* eslint-disable comma-dangle */
/* eslint-disable require-jsdoc */
/* eslint-disable max-len */
const {onRequest} = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
admin.initializeApp();

const db = admin.database();

// Danh sách member cứng giống như trong mã nguồn Azure của bạn
const memberList = ["8501091017577725160", "3706931116048822880",
 
  "8238478985986168389", "5163894976803610296",
  "8501091017577725160", "3227439752531646171", "4499434538963877728",
  "8381055013453744990", "7251355754441520560",
  "366075136541843717", "1506600698618940665",
  "5640126963832781652", "4515192710655305656"];
  //  "1430490703128541643", , "6852602033450956296" , "7588112101555099487"

exports.api = onRequest({region: "asia-southeast1", cors: true}, async (req, res) => {
  const method = req.method.toLowerCase();

  try {
    switch (method) {
      case "post":
        await handlePost(req, res);
        break;
      case "get":
        await handleGet(req, res);
        break;
        // Lưu ý: PUT không được hỗ trợ trực tiếp, POST được dùng cho cả tạo và cập nhật.
        // Logic `handleUpdate` gốc có vẻ không chính xác, logic tạo/cập nhật đã được tích hợp trong `handlePost`.
      default:
        res.status(405).send("Method Not Allowed");
        break;
    }
  } catch (error) {
    console.error("Error:", error);
    res.status(500).send(`Error: ${error.message}`);
  }
});

// Thay thế hoàn toàn hàm handlePost cũ bằng hàm này
async function handlePost(req, res) {
  const {userID, username, participantDate, status, avatar, isMember, type} = req.body;

  // Sửa lỗi bằng cách ép kiểu `isMember` thành boolean một cách an toàn
  // Dấu !! sẽ chuyển đổi (undefined, null, false) thành `false` và các giá trị khác thành `true`.
  const isUserMember = memberList.includes(userID) || !!isMember;

  // 1. Cập nhật hoặc tạo User nếu có avatar
  if (avatar !== undefined) {
    const userRef = db.ref(`/users/${userID}`);
    const userAccount = {
      userID,
      username,
      isMember: isUserMember, // <-- Đã sửa lỗi
      avatar,
      status
    };
    await userRef.update(userAccount);
    console.log("Upserted user:", userID);
  }

  // 2. Tạo hoặc cập nhật Participant
  const participantData = {
    userID,
    username,
    participantDate,
    status,
    isMember: isUserMember, // <-- Đã sửa lỗi
    type: type || null,
    timestamp: admin.database.ServerValue.TIMESTAMP
  };

  // Tìm kiếm một bản ghi participant hiện có để cập nhật
  const query = db.ref("/participants").orderByChild("userID").equalTo(userID);
  const snapshot = await query.once("value");

  let existingParticipantKey = null;

  if (snapshot.exists()) {
    snapshot.forEach((childSnapshot) => {
      const childData = childSnapshot.val();
      // Điều kiện khớp để cập nhật: cùng `participantDate` và `type`
      const existingType = childData.type || null;
      const newType = participantData.type || null;
      if (childData.participantDate === participantDate && existingType === newType) {
        existingParticipantKey = childSnapshot.key;
      }
    });
  }

  if (existingParticipantKey) {
    // Cập nhật bản ghi đã có
    const participantRef = db.ref(`/participants/${existingParticipantKey}`);
    // === THAY ĐỔI Ở ĐÂY ===
    // Thêm timestamp vào để nó được cập nhật mỗi khi status thay đổi
    const updateData = {
      status: status,
      isMember: isUserMember,
      timestamp: admin.database.ServerValue.TIMESTAMP // <--- Thêm dòng này
    };
    await participantRef.update(updateData);
    // === KẾT THÚC THAY ĐỔI ===

    const updatedData = (await participantRef.once("value")).val();
    res.status(200).json(updatedData);
  } else {
    // Tạo bản ghi mới
    const newParticipantRef = db.ref("/participants").push();
    await newParticipantRef.set(participantData);
    const newData = (await newParticipantRef.once("value")).val();
    res.status(201).json({id: newParticipantRef.key, ...newData});
  }
}
// Thay thế hàm handleGet cũ bằng hàm này
// File backend (ví dụ: index.js của Firebase Functions)

async function handleGet(req, res) {
  const {userID, participantDate, type, getConfig} = req.query; // Thêm getConfig

  // === THÊM MỚI TẠI ĐÂY ===
  // Endpoint để lấy cấu hình chung
  if (getConfig === "true") {
    const configRef = db.ref("/config");
    const snapshot = await configRef.once("value");
    const configData = snapshot.val() || {mainTitle: "Lịch tham gia"}; // Giá trị mặc định
    res.status(200).json(configData);
    return; // Kết thúc hàm tại đây
  }
  // === KẾT THÚC PHẦN THÊM MỚI ===
  if (userID) {
    // Phần này đã đúng, không cần sửa
    const query = db.ref("/participants").orderByChild("userID").equalTo(userID);
    const snapshot = await query.once("value");
    const items = [];
    snapshot.forEach((child) => {
      const data = child.val();
      if (!type || (type && data.type === type)) {
        items.push({id: child.key, ...data});
      }
    });
    items.sort((a, b) => b.timestamp - a.timestamp);
    res.status(200).json(items);
  } else if (participantDate) { // Lấy danh sách tham gia theo ngày
    if (participantDate === "9999") { // Lấy tất cả người tham gia
      const usersSnapshot = await db.ref("/users").once("value");
      const users = usersSnapshot.val() || {};

      const participantsSnapshot = await db.ref("/participants").once("value");
      const items = [];

      participantsSnapshot.forEach((child) => {
        const data = child.val();

        // === THAY ĐỔI Ở ĐÂY: Bỏ điều kiện if (data.status === "yes") ===
        const userItem = users[data.userID];
        items.push({
          ...data,
          avatar: userItem ? userItem.avatar : null,
        });
        // === KẾT THÚC THAY ĐỔI ===
      });
      res.status(200).json(items);
    } else { // Lấy theo một ngày cụ thể
      const query = db.ref("/participants").orderByChild("participantDate").equalTo(participantDate);
      const snapshot = await query.once("value");
      const items = [];
      snapshot.forEach((child) => {
        const data = child.val();

        // === THAY ĐỔI Ở ĐÂY: Bỏ điều kiện data.status === "yes" ===
        if (!type || data.type === type) {
          items.push({
            // Giữ nguyên các trường cần thiết
            ...data
          });
        }
        // === KẾT THÚC THAY ĐỔI ===
      });
      res.status(200).json(items);
    }
  } else {
    res.status(400).send("Invalid query parameters.");
  }
}